// components/knowledge/intake/modal/knowledge-intake-modal.tsx
"use client";

import { useState } from "react";
import { Dialog, DialogContent } from "@/components/ui/dialog";

import { useKnowledgeIntake } from "../hooks/use-knowledge-intake";
import { KnowledgeIntakeModalHeader } from "./knowledge-intake-modal-header";
import { KnowledgeIntakeModalProgress } from "./knowledge-intake-modal-progress";
import { KnowledgeIntakeUploadStep } from "./knowledge-intake-upload-step";
import { KnowledgeIntakeAnalysisStep } from "./knowledge-intake-analysis-step";
import { KnowledgeIntakeProposalStep } from "./knowledge-intake-proposal-step";
import { KnowledgeIntakeCompletedStep } from "./knowledge-intake-completed-step";
import { KnowledgeIntakeCloseGuard } from "./knowledge-intake-close-guard";
import { KnowledgeIntakeLoadingOverlay } from "./knowledge-intake-loading-overlay";
import type { KnowledgeIntakeModalProps } from "./knowledge-intake-modal.types";

export function KnowledgeIntakeModal({
  open,
  context,
  onOpenChange,
  onCompleted,
  selectedFiles,
}: KnowledgeIntakeModalProps) {
  const [closeGuardOpen, setCloseGuardOpen] = useState(false);

  const intake = useKnowledgeIntake({
    context: context!,
    onCompleted,
  });

  if (!context) return null;

  function requestClose() {
    if (intake.hasUnsavedProgress) {
      setCloseGuardOpen(true);
      return;
    }
    onOpenChange(false);
  }

  if (selectedFiles?.length && intake.files.length === 0) {
    intake.handleFilesChange(selectedFiles);
  }

  return (
    <>
      <Dialog open={open} onOpenChange={(next) => !next && requestClose()}>
        <DialogContent
          showCloseButton
          style={{
            width: "1100px",
            maxWidth: "90vw",
            height: "720px",
            maxHeight: "88vh",
          }}
          className="flex flex-col gap-0 overflow-hidden p-0"
        >
          <KnowledgeIntakeModalHeader context={context} />
          <KnowledgeIntakeModalProgress currentStep={intake.step} />

          {/* 👇 AQUÍ es donde va el cambio: dentro de esta zona de contenido,
              sustituyendo lo que antes eran dos elementos (proposal step + overlay)
              por un único bloque condicional */}
          <div className="min-h-0 flex-1 overflow-y-auto px-6 py-5">
            {intake.step === "upload" && (
              <KnowledgeIntakeUploadStep
                files={intake.files}
                isAnalyzing={intake.isAnalyzing}
                error={intake.error}
                onFilesChange={intake.handleFilesChange}
                onAnalyze={intake.analyzeDocuments}
              />
            )}

            {intake.step === "analyzing" && <KnowledgeIntakeAnalysisStep />}

            {intake.step === "proposal" && intake.proposal && (
              intake.isConfirming ? (
                <KnowledgeIntakeLoadingOverlay />
              ) : (
                <KnowledgeIntakeProposalStep
                  proposal={intake.proposal}
                  isConfirming={intake.isConfirming}
                  error={intake.error}
                  onBack={intake.goBackToUpload}
                  onConfirm={intake.confirmProposal}
                />
              )
            )}

            {intake.step === "completed" && intake.completionResult && (
              <KnowledgeIntakeCompletedStep
                result={intake.completionResult}
                onReset={intake.reset}
                onClose={() => onOpenChange(false)}
              />
            )}
          </div>
        </DialogContent>
      </Dialog>

      <KnowledgeIntakeCloseGuard
        open={closeGuardOpen}
        onOpenChange={setCloseGuardOpen}
        onConfirmClose={() => {
          setCloseGuardOpen(false);
          intake.reset();
          onOpenChange(false);
        }}
      />
    </>
  );
}