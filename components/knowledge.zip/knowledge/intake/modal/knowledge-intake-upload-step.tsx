// components/knowledge/intake/modal/knowledge-intake-upload-step.tsx
import { useRef } from "react";
import { Plus, Sparkles } from "lucide-react";

import { Button } from "@/components/ui/button";
import { KnowledgeUploadFileCard } from "@/components/knowledge/upload-file-card";

type Props = {
  files: File[];
  isAnalyzing: boolean;
  error: string | null;
  onFilesChange: (files: File[]) => void;
  onAnalyze: () => void;
};

export function KnowledgeIntakeUploadStep({ files, isAnalyzing, error, onFilesChange, onAnalyze }: Props) {
  const inputRef = useRef<HTMLInputElement>(null);

  function handleAddMore(event: React.ChangeEvent<HTMLInputElement>) {
    const picked = Array.from(event.target.files ?? []);
    event.target.value = "";
    if (picked.length) onFilesChange([...files, ...picked]);
  }

  function handleRemove(file: File) {
    onFilesChange(files.filter((f) => f !== file));
  }

  return (
    <div className="flex flex-col gap-5">
      <div className="space-y-2">
        {files.map((file) => (
          <KnowledgeUploadFileCard
            key={`${file.name}-${file.lastModified}`}
            file={file}
            disabled={isAnalyzing}
            isUploading={isAnalyzing}
            onRemove={handleRemove}
          />
        ))}
      </div>

      <input ref={inputRef} type="file" multiple hidden onChange={handleAddMore} />

      <Button type="button" variant="outline" disabled={isAnalyzing} onClick={() => inputRef.current?.click()}>
        <Plus className="mr-2 h-4 w-4" />
        Añadir más archivos
      </Button>

      {error ? <div className="rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700">{error}</div> : null}

      <div className="flex justify-end">
        <Button type="button" disabled={isAnalyzing || files.length === 0} onClick={onAnalyze} className="bg-cyan-600 text-white hover:bg-cyan-700">
          <Sparkles className="mr-2 h-4 w-4" />
          Analizar antes de incorporar
        </Button>
      </div>
    </div>
  );
}